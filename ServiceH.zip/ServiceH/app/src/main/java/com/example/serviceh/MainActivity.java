package com.example.serviceh;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.safetynet.SafetyNet;
import com.google.android.gms.safetynet.SafetyNetApi;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.logging.Logger;

public class MainActivity extends AppCompatActivity implements GoogleApiClient.ConnectionCallbacks {

    EditText e1,e2;
Button b1;
TextView t,t1;
FirebaseAuth fire;
    CheckBox check;
    GoogleApiClient gclient;
String key="6LcuHegUAAAAABTm5okIFRlQsK9w2QRLHlX9Zd51";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fire=FirebaseAuth.getInstance();
        e1=findViewById(R.id.email);
        e2=findViewById(R.id.pass);
        b1=findViewById(R.id.log);
        t=findViewById(R.id.regi);
        t1=findViewById(R.id.forg);
        isNetworkAvailable(this);
        check=findViewById(R.id.check);
        gclient=new GoogleApiClient.Builder(this).addApi(SafetyNet.API).addConnectionCallbacks(MainActivity.this).build();
        gclient.connect();
        check.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (check.isChecked()){
SafetyNet.SafetyNetApi.verifyWithRecaptcha(gclient,key).setResultCallback(new ResultCallback<SafetyNetApi.RecaptchaTokenResult>() {
    @Override
    public void onResult(@NonNull SafetyNetApi.RecaptchaTokenResult recaptchaTokenResult) {
        Status status= recaptchaTokenResult.getStatus();
        if ((status !=null) && status.isSuccess()){
            Toast.makeText(MainActivity.this,"Now Your Ready To Login",Toast.LENGTH_LONG).show();
        }

    }
});
                }
            }
        });
       if (fire.getCurrentUser() != null) {
            // User is logged in
            startActivity(new Intent(this, Activity_Home.class));
            finish();
        }

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String s1= e1.getText().toString();
                String s2=e2.getText().toString();
                if (s1.isEmpty() && s2.isEmpty()){
                    Toast.makeText(MainActivity.this,"Please Fill",Toast.LENGTH_LONG).show();

                }
                else if(s1.isEmpty()){
                    Toast.makeText(MainActivity.this,"Please Fill Email",Toast.LENGTH_LONG).show();
                }
                else if(s2.isEmpty()){
                    Toast.makeText(MainActivity.this,"Please Fill Password",Toast.LENGTH_LONG).show();
                }
                else if (!check.isChecked()){
                    Toast.makeText(MainActivity.this,"Please Verfiy your Not Robot",Toast.LENGTH_LONG).show();
                }

              else  if(!s1.isEmpty() && !s2.isEmpty() && check.isChecked()) {
                    fire.signInWithEmailAndPassword(s1,s2).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if(!task.isSuccessful()){
                                Toast.makeText(MainActivity.this,"Login Unsuccessful",Toast.LENGTH_LONG).show();
                            }
                            else{
                                Intent n = new Intent(MainActivity.this, Activity_Home.class);
                                startActivity(n);
                            }
                        }
                    });
                }

                else{
                    Toast.makeText(MainActivity.this,"Error in Login",Toast.LENGTH_LONG).show();
                }
            }
        });
    t.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent n = new Intent(MainActivity.this, Register.class);
            startActivity(n);
        }
    });
        t1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent n = new Intent(MainActivity.this, Activity_Forgetpass.class);
                startActivity(n);
            }
        });
    }


    public boolean isNetworkAvailable(Context context) {
        final ConnectivityManager connMgr = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);

        if (connMgr != null) {
            NetworkInfo activeNetworkInfo = connMgr.getActiveNetworkInfo();

            if (activeNetworkInfo != null) { // connected to the internet
                // connected to the mobile provider's data plan
                if (activeNetworkInfo.getType() == ConnectivityManager.TYPE_WIFI) {
                    // connected to wifi
                    return true;
                } else return activeNetworkInfo.getType() == ConnectivityManager.TYPE_MOBILE;
            }
        }
        Toast.makeText(MainActivity.this,"Please Connect to Internet",Toast.LENGTH_LONG).show();
        return false;
    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {

    }

    @Override
    public void onConnectionSuspended(int i) {

    }
}
