package com.example.serviceh;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.MenuItemCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;
import java.util.List;

public class Hospital extends AppCompatActivity {
    List<Hospital_list> hospitallistList;
    FirebaseAuth fire;
    private FirebaseAuth.AuthStateListener listener;
    //the recyclerview
    RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hospital);
        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottom_navigation);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.home:
                        Intent n = new Intent(Hospital.this, Activity_Home.class);
                        startActivity(n);

                        break;
                    case R.id.police:
                        Intent k=new Intent(Hospital.this,Hospital.class);
                        startActivity(k);
                        break;
                    case R.id.location:
                        Intent m = new Intent(Hospital.this, Locationmap.class);
                        startActivity(m);
                        break;                }
                return true;
            }
        });

        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        hospitallistList = new ArrayList<>();

        hospitallistList.add(
                new Hospital_list(
                        1,
                        "Punamiya Hospital",
                        "101, Inder Tower, Gokhale Rd, near Tilak Bhavan, Dadar West, Mumbai, Maharashtra 400028",
                        R.drawable.ic_punamiyahospital));

        hospitallistList.add(
                new Hospital_list(
                        2,
                        "Shreedhar Hospital",
                        " Room No. 11, Anil Co-operative Society, M.T.N.L Lane, Near Prabhadevi Tele Exchange, Dadar West, Mumbai, Maharashtra 400028",
                        R.drawable.ic_shreedharhospital));

        hospitallistList.add(
                new Hospital_list(
                        3,
                        "Sanjeevanee Hospital",
                        "172/A, Naigaum, Dadar East, Mahatma Jyotiba Phule Road, Mumbai, Maharashtra 400014",
                        R.drawable.ic_sanjeevaneehospital));
        hospitallistList.add(
                new Hospital_list(
                        4,
                        "Thakur Hospital",
                        "Vidya Bhavan, 1st Floor, 121, Shivaji Park, Opposite Shivsena Bhavan, Dadar West, Mumbai, Maharashtra 400028",

                        R.drawable.ic_thakurhospital));

        hospitallistList.add(
                new Hospital_list(
                        1,
                        "Navneet Jain Health Centre",
                        "12, Gyan Mandir Road, Near Kabutar khana, Dadar West, Dadar, Mumbai, Maharashtra 400028",

                        R.drawable.ic_navneetjainhealthcentre));

        hospitallistList.add(
                new Hospital_list(
                        5,
                        "Pai Hospital",
                        "162/A, Lady Jehangir Rd, Hindu Colony, Dadar, Mumbai, Maharashtra 400014",

                        R.drawable.ic_paihospital));
        hospitallistList.add(
                new Hospital_list(
                        6,
                        "Gadre Hospital",
                        "SM Jadhav Rd, Hindmata, Radhika Saikripa Co-op Society, Naigaon, Parel, Mumbai, Maharashtra 400014",

                        R.drawable.ic_swachh_bharat));

        hospitallistList.add(
                new Hospital_list(
                        7,
                        "Jeevak Hospital",
                        "Opposite Aslad Bus Stand, Dadar T.T, MMGS Marg, Dadar, Mumbai, Maharashtra 400014",

                        R.drawable.ic_swachh_bharat));

        hospitallistList.add(
                new Hospital_list(
                        8,
                        "Dr. Vaze Hospital",
                        "Meghdoot, SH Paralkar Marg, Chandrakant Dhuru Wadi, Dadar, Mumbai, Maharashtra 400028",
                        R.drawable.ic_swachh_bharat));

        //creating recyclerview adapter
        HospitalAdapter adapter = new HospitalAdapter(this, hospitallistList);

        //setting adapter to recyclerview
        recyclerView.setAdapter(adapter);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater in =getMenuInflater();
        in.inflate(R.menu.topmenu,menu);

        return true;


    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.logout:
                fire.getInstance().signOut();
                Intent n= new Intent( this,MainActivity.class);
                startActivity(n);

        }
        return super.onOptionsItemSelected(item);
    }

}
