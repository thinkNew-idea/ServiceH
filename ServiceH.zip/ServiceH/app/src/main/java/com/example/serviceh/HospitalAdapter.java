package com.example.serviceh;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class HospitalAdapter extends RecyclerView.Adapter<HospitalAdapter.ProductViewHolder> {


    private Context mCtx;

    private List<Hospital_list> hospitallistList;

    public HospitalAdapter(Context mCtx, List<Hospital_list> hospitallistList) {
        this.mCtx = mCtx;
        this.hospitallistList = hospitallistList;
    }

    @Override
    public ProductViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        //inflating and returning our view holder
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.single_hospital, null);
        return new ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ProductViewHolder holder, int position) {
        //getting the product of the specified position
        Hospital_list hospitallist = hospitallistList.get(position);

        holder.Title.setText(hospitallist.getTitle());
        holder.Address.setText(hospitallist.getShortdesc());
        holder.imageView.setImageDrawable(mCtx.getResources().getDrawable(hospitallist.getImage()));

    }


    @Override
    public int getItemCount() {
        return hospitallistList.size();
    }


    class ProductViewHolder extends RecyclerView.ViewHolder {

        TextView Title, Address;
        ImageView imageView;

        public ProductViewHolder(View itemView) {
            super(itemView);

            Title = itemView.findViewById(R.id.textViewTitle);
            Address = itemView.findViewById(R.id.textViewShortDesc);
            imageView = itemView.findViewById(R.id.imageView);
        }
    }
}