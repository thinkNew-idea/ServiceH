package com.example.serviceh;

public class Hospital_list {

        private int id;
        private String title;
        private String Address;

        private int image;

        public Hospital_list(int id, String title, String Address, int image) {
            this.id = id;
            this.title = title;
            this.Address = Address;
            this.image = image;
        }

        public int getId() {
            return id;
        }

        public String getTitle() {
            return title;
        }

        public String getShortdesc() {
            return Address;
        }


        public int getImage() {
            return image;
        }
    }

