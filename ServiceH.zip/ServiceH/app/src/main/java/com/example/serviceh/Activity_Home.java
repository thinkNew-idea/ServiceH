package com.example.serviceh;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.MenuItemCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.Toast;

import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.safetynet.SafetyNet;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;

public class Activity_Home extends AppCompatActivity {
Button b1,b2;
    private  static  final  int REQUEST_CALL=1;
    private  static  final  int REQUEST_CALL1=2;
    FirebaseAuth fire;

    private FirebaseAuth.AuthStateListener listener;
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater in =getMenuInflater();
        in.inflate(R.menu.topmenu,menu);

        return true;


    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()){
            case R.id.logout:
                fire.getInstance().signOut();
                Intent n= new Intent( this,MainActivity.class);
                startActivity(n);
                break;

            case R.id.about:
                Intent k = new Intent(this, AboutNewActivity.class);
                startActivity(k);
                break;


   }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity__home);
        b1=findViewById(R.id.doctor);
        b2=findViewById(R.id.policeman);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int num=102;
                if (ContextCompat.checkSelfPermission(Activity_Home.this, Manifest.permission.CALL_PHONE)!= PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(Activity_Home.this,new String[]{Manifest.permission.CALL_PHONE},REQUEST_CALL);

                }
                else{
                    String dail= "tel:"+num;
                    startActivity(new Intent(Intent.ACTION_CALL, Uri.parse(dail)));

                }
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int num=100;
                if (ContextCompat.checkSelfPermission(Activity_Home.this, Manifest.permission.CALL_PHONE)!= PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(Activity_Home.this,new String[]{Manifest.permission.CALL_PHONE},REQUEST_CALL1);
                }
                else{
                    String dail= "tel:"+num;
                    startActivity(new Intent(Intent.ACTION_CALL, Uri.parse(dail)));

                }
            }
        });
        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottom_navigation);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.home:
                        Intent n = new Intent(Activity_Home.this, Activity_Home.class);
                        startActivity(n);

                        break;
                    case R.id.police:
Intent k=new Intent(Activity_Home.this,Hospital.class);
startActivity(k);
                        break;
                    case R.id.location:
                        Intent m = new Intent(Activity_Home.this, Locationmap.class);
                        startActivity(m);
                        break;                }
                return true;
            }
        });
    }
}