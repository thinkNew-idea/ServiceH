package com.example.serviceh;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Register extends AppCompatActivity {

    EditText e1,e2,e3;
    Button b1;
FirebaseAuth fire;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        e1=findViewById(R.id.email);
        e2=findViewById(R.id.pass);
        e3=findViewById(R.id.cpass);
        b1=findViewById(R.id.regi);
        fire=FirebaseAuth.getInstance();
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (e1.getText().toString().isEmpty() && e2.getText().toString().isEmpty()){
                    Toast.makeText(Register.this,"Please Fill",Toast.LENGTH_LONG).show();

                }
                else if(e1.getText().toString().isEmpty()){
                    Toast.makeText(Register.this,"Please Fill Email",Toast.LENGTH_LONG).show();
                }
                else if(e2.getText().toString().isEmpty()){
                    Toast.makeText(Register.this,"Please Fill Password",Toast.LENGTH_LONG).show();
                }else if(e3.getText().toString().isEmpty()){
                    Toast.makeText(Register.this,"Please Fill Confirm Password",Toast.LENGTH_LONG).show();
                }
                else if(!e2.getText().toString().matches(e3.getText().toString())){
                    Toast.makeText(Register.this,"Recheck Your Password",Toast.LENGTH_LONG).show();
                }
                else if(!e1.getText().toString().isEmpty() && e2.getText().toString().matches(e3.getText().toString()) && !e2.getText().toString().isEmpty() && !e3.getText().toString().isEmpty() )
                {
fire.createUserWithEmailAndPassword(e1.getText().toString(),e2.getText().toString())
        .addOnCompleteListener(Register.this, new OnCompleteListener<AuthResult>() {
    @Override
    public void onComplete(@NonNull Task<AuthResult> task) {
       if (!task.isSuccessful()){
           Toast.makeText(Register.this,"Registration Unsuccessful",Toast.LENGTH_LONG).show();
       }
       else{
           startActivity(new Intent(Register.this,MainActivity.class));
       }
    }
});
                }
                else{

                    Toast.makeText(Register.this,"Error While Registration",Toast.LENGTH_LONG).show();

                }
            }
        });

    }
}
